11/08: Working on moving stuff into the header files so I can use them across all classes.
11/09: header stuff g2g need to parse and not print poke, stats, pokemoves, and moves.
11/09: Random spawn (% 10 = 0) working and parsing is working to get needed info.
11/10: Everything should be done I think. Manhattan stuff working. Another all nighter fun one :L